#!/bin/sh
cat ./flag.txt
