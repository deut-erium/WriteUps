We have devised this challenge to test how good our hash-encryption implementation is.

The key bytes for the block's hash (`32` char) is in rockyou.txt.

```
NQAAAAAAAAAYAAAAAAAAAHdpQUdqMmNXSFZDeTRhT29pOVJTVVhmRzUAAAAAAAAA1xBwynYemGSu4JEuX9qyySHcU30P41El0Eva+Dsh1p/semEp6LKlvKKKJKwkLqqbOsys+9c=
```

Good Luck!