#!/bin/sh
unzip -p -P$(cat ../password.alice) flag.zip
