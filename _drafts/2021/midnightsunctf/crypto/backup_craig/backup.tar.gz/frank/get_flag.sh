#!/bin/sh
cat ../password.frank
