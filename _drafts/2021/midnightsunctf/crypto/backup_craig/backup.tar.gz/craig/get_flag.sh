#!/bin/sh
unzip -p -P$(cat ../password.craig) flag.zip
